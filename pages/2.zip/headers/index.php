<?php

//header("Location: test.html");
header("MyHeader: test");


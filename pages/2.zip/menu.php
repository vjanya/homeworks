<div>
    <a href="/">Home</a>
    <a href="?page=about">About Us</a>
    <a href="?page=products">Products</a>
    <a href="?page=contacts">Contacts</a>
</div>
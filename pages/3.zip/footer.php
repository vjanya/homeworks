<div>&copy; 2016 My Site</div>

<?php include "cookies/index.php"; ?>
